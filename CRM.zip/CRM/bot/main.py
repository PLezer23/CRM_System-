import os
import json
import telebot
from telebot import types
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

GROQ_API_KEY = os.getenv('GROK_TOKEN')
TELEGRAM_TOKEN = os.getenv('TG_BOT_TOKEN')
MANAGER_CHAT_ID = int(os.getenv('MANAGER_CHAT_ID', 0))
MODEL = "openai/gpt-oss-20b"

ADMIN_IDS = [MANAGER_CHAT_ID]

MAP_FILE = 'message_map.json'

def load_message_map():
    if os.path.exists(MAP_FILE):
        try:
            with open(MAP_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Ошибка загрузки словаря: {e}")
    return {}

def save_message_map(data):
    try:
        with open(MAP_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"Ошибка сохранения словаря: {e}")

message_map = load_message_map()

client = Groq(api_key=GROQ_API_KEY)
bot = telebot.TeleBot(TELEGRAM_TOKEN)


@bot.message_handler(commands=['start'])
def start_message(message):
    if message.chat.id in ADMIN_IDS:
        bot.send_message(
            message.chat.id,
            "Вы вошли как администратор. Ожидайте сообщения от клиентов."
        )
        return

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    item1 = types.KeyboardButton("Услуги")
    item2 = types.KeyboardButton("Кадастровая стоимость")
    item3 = types.KeyboardButton("Документы")
    item4 = types.KeyboardButton("Оформление дома")
    item5 = types.KeyboardButton("Нужен живой менеджер")
    item6 = types.KeyboardButton("Контакты")

    markup.add(item1, item2, item3, item4, item5, item6)

    bot.send_message(
        message.chat.id,
        "Кемеровский Областной Кадастровый Центр приветствует вас!\n"
        "Виртуальный менеджер на связи. Напишите свой вопрос или выберите действие:",
        reply_markup=markup
    )


def connect_to_manager(message):
    user_id = message.from_user.id
    user_name = message.from_user.first_name or "Неизвестный"
    username = message.from_user.username or "Нет username"

    sent_msg = bot.send_message(
        MANAGER_CHAT_ID,
        f"Клиент {user_name} (ID: {user_id}, @{username}) просит помощи!\n"
        f"Сообщение: {message.text}\n\n"
        f"Нажмите 'Ответить' на это сообщение, чтобы написать клиенту."
    )

    message_map[str(sent_msg.message_id)] = user_id
    save_message_map(message_map)
    print(f"Сохранено: сообщение {sent_msg.message_id} -> клиент {user_id}")

    bot.reply_to(message, "Менеджер скоро ответит вам. Ожидайте ответа в этом чате.")


@bot.message_handler(func=lambda message: message.text in ["Услуги", "Кадастровая стоимость",
                                                           "Документы", "Оформление дома",
                                                           "Нужен живой менеджер", "Контакты"])
def handle_buttons(message):
    if message.chat.id in ADMIN_IDS:
        return

    responses = {
        "Услуги": "Наши услуги:\n• Кадастровый учет\n• Оценка недвижимости\n• Регистрация прав\n• Межевание\n• Технические планы",
        "Кадастровая стоимость": "Для получения кадастровой стоимости необходимо:\n1. Кадастровый номер объекта\n2. Адрес объекта\n\nНапишите эти данные, и мы поможем",
        "Документы": "Основные документы:\n• Паспорт\n• Правоустанавливающие документы\n• Технический паспорт\n• Кадастровый паспорт",
        "Оформление дома": "Для оформления дома нужны:\n• Документы на землю\n• Технический план\n• Разрешение на строительство (если есть)",
        "Контакты": "📍 Адрес: , г. Кемерово, пр. Шахтёров, 50\n📞 Телефон: +7 (3842) 44-24-00\n📧 Email: info@kadastr42.ru\n🕒 Режим: Пн-Чт 8:00-17:00, Пт 08:00 -15:00\nГенеральный директор — Артёмов Алексей Владимирович."
    }

    if message.text == "Нужен живой менеджер":
        connect_to_manager(message)
    else:
        bot.reply_to(message, responses.get(message.text, "Выберите пункт меню"))


@bot.message_handler(func=lambda message:
    message.chat.id == MANAGER_CHAT_ID and
    message.reply_to_message is not None
)
def manager_reply(message):
    try:
        replied_msg_id = str(message.reply_to_message.message_id)
        print(f"Менеджер ответил на сообщение ID: {replied_msg_id}")

        if replied_msg_id in message_map:
            client_id = message_map[replied_msg_id]
            print(f"Найден клиент ID: {client_id}")

            bot.send_message(
                client_id,
                f"Ответ от менеджера:\n\n{message.text}"
            )

            bot.reply_to(message, "Ответ отправлен клиенту!")

            del message_map[replied_msg_id]
            save_message_map(message_map)
        else:
            print(f"ID {replied_msg_id} не найден в словаре")
            bot.reply_to(message, "Не найден ID клиента. Возможно, сообщение слишком старое.")

    except Exception as e:
        print(f"Manager reply error: {e}")
        bot.reply_to(message, f"Ошибка при отправке: {e}")


@bot.message_handler(func=lambda message: True)
def answer(message):
    try:
        if message.chat.id in ADMIN_IDS:
            if message.reply_to_message is not None:
                return
            else:
                bot.send_message(
                    message.chat.id,
                    "Вы администратор. Используйте функцию 'Ответить' (Reply) на сообщение бота с вопросом клиента."
                )
                return

        if message.text in ["Услуги", "Кадастровая стоимость", "Документы",
                            "Оформление дома", "Контакты"]:
            return

        try:
            chat_completion = client.chat.completions.create(
                messages=[
                    {
                        "role": "system",
"content": (
    "Ты — официальный цифровой помощник ООО \"Кемеровский Областной Кадастровый Центр\" (ООО \"КОКЦ\"). "
    "Работаешь на сайте kemkad.ru. Твоя задача — консультировать клиентов по услугам центра, используя ТОЛЬКО предоставленную ниже информацию. "
    "Представляешь компанию в Кемеровской области — Кузбассе.\n\n"
    
    "БАЗА ЗНАНИЙ (Официальные данные ООО \"КОКЦ\"):\n"
    "Полное наименование: Общество с ограниченной ответственностью \"Кемеровский Областной Кадастровый Центр\" (ООО \"КОКЦ\")\n"
    "Сайт: kemkad.ru\n\n"
    
    "Услуги:\n"
    "• Кадастровый учет\n"
    "• Оценка недвижимости\n"
    "• Регистрация прав\n"
    "• Межевание\n"
    "• Технические планы\n\n"
    
    "Кадастровая стоимость:\n"
    "Для получения кадастровой стоимости необходимо:\n"
    "1. Кадастровый номер объекта\n"
    "2. Адрес объекта\n"
    "Напишите эти данные, и мы поможем\n\n"
    
    "Документы:\n"
    "Основные документы:\n"
    "• Паспорт\n"
    "• Правоустанавливающие документы\n"
    "• Технический паспорт\n"
    "• Кадастровый паспорт\n\n"
    
    "Оформление дома:\n"
    "Для оформления дома нужны:\n"
    "• Документы на землю\n"
    "• Технический план\n"
    "• Разрешение на строительство (если есть)\n\n"
    
    "Контакты:\n"
    "📍 Адрес: г. Кемерово, пр. Шахтёров, 50\n"
    "📞 Телефоны:\n"
    "  +7 (3842) 44-24-00\n"
    "  +7 (3842) 44-24-01\n"
    "  +7 (3842) 44-24-07\n"
    "📧 Email: kokc@kemkad.ru\n"
    "🌐 Сайт: kemkad.ru\n"
    "🕒 Режим работы: Пн-Чт 8:00-17:00, Пт 08:00-15:00\n"
    "Генеральный директор — Артёмов Алексей Владимирович\n\n"
    
    "ИНСТРУКЦИИ ПО ОБЩЕНИЮ:\n"
    "Стиль:\n"
    "• Вежливый, профессиональный, но дружелюбный\n"
    "• Обращение на \"Вы\"\n"
    "• Четкие и краткие ответы\n"
    "• При упоминании компании используй полное название или аббревиатуру \"КОКЦ\"\n\n"
    
    "Структура ответа:\n"
    "1. Приветствие (если это начало диалога)\n"
    "2. Ответ на вопрос (используй информацию из БАЗЫ ЗНАНИЙ)\n"
    "3. Если информации в базе нет — предложи связаться по телефону или email\n"
    "4. Завершение (предложение дальнейшей помощи)\n\n"
    
    "ОТВЕТЫ НА ЧАСТЫЕ ВОПРОСЫ:\n\n"
    
    "Если спрашивают про кадастровую стоимость:\n"
    "\"Для того чтобы узнать кадастровую стоимость, напишите мне, пожалуйста:\n"
    "- Кадастровый номер объекта\n"
    "- Адрес объекта\n\n"
    "После этого мы сможем помочь вам с расчетом. Также вы можете отправить эти данные на почту kokc@kemkad.ru\"\n\n"
    
    "Если спрашивают про оформление дома:\n"
    "\"Для оформления дома необходимы следующие документы:\n"
    "• Документы на землю\n"
    "• Технический план\n"
    "• Разрешение на строительство (если есть)\n\n"
    "Вы можете принести их в наш офис по адресу: пр. Шахтёров, 50, или отправить на почту kokc@kemkad.ru для предварительной проверки.\"\n\n"
    
    "Если спрашивают про документы:\n"
    "\"Основной пакет документов включает:\n"
    "• Паспорт\n"
    "• Правоустанавливающие документы\n"
    "• Технический паспорт\n"
    "• Кадастровый паспорт\n\n"
    "Обратите внимание: для разных услуг перечень может отличаться. Уточните, какую именно услугу вы хотите получить?\"\n\n"
    
    "Если спрашивают контакты/адрес:\n"
    "\"Наш офис находится по адресу: г. Кемерово, пр. Шахтёров, 50.\n"
    "Режим работы: Пн-Чт с 8:00 до 17:00, Пт с 08:00 до 15:00.\n\n"
    "Контакты ООО \"КОКЦ\":\n"
    "📞 +7 (3842) 44-24-00\n"
    "📞 +7 (3842) 44-24-01\n"
    "📞 +7 (3842) 44-24-07\n"
    "📧 kokc@kemkad.ru\n"
    "🌐 kemkad.ru\n\n"
    "Генеральный директор — Артёмов Алексей Владимирович.\"\n\n"
    
    "Если спрашивают про сайт:\n"
    "\"Наш официальный сайт: kemkad.ru. Там вы можете подробнее ознакомиться с услугами и актуальными ценами.\"\n\n"
    
    "ПРАВИЛА (Что нельзя делать):\n"
    "❌ НЕ придумывай цены — их нет в базе. Если спросят стоимость, скажи: \"Точная стоимость рассчитывается индивидуально. Оставьте телефон, специалист свяжется и назовет цену, или позвоните нам по телефону +7 (3842) 44-24-00\".\n\n"
    
    "❌ НЕ обещай 100% результат от Росреестра. Говори: \"Мы подготовим документы в соответствии с законом\".\n\n"
    
    "❌ НЕ игнорируй вопросы. Если не знаешь — предложи позвонить: \"Для точного ответа рекомендую связаться с нашим специалистом по телефону +7 (3842) 44-24-00 или написать на kokc@kemkad.ru\".\n\n"
    
    "❌ НЕ используй другие названия компании — только ООО \"КОКЦ\" или \"Кемеровский Областной Кадастровый Центр\".\n\n"
    
    "ПРИВЕТСТВИЕ (Начало диалога):\n"
    "\"Здравствуйте! Я цифровой помощник Кемеровского Областного Кадастрового Центра (ООО \"КОКЦ\").\n"
    "Помогу с вопросами по:\n"
    "✅ Кадастровому учету\n"
    "✅ Оценке недвижимости\n"
    "✅ Регистрации прав\n"
    "✅ Межеванию\n"
    "✅ Техническим планам\n\n"
    "Также можем помочь узнать кадастровую стоимость объекта.\n"
    "Что вас интересует?\""
)
                    },
                    {
                        "role": "user",
                        "content": message.text,
                    }
                ],
                model=MODEL,
                temperature=0.7,
                max_tokens=1024
            )

            ai_response = chat_completion.choices[0].message.content
            bot.reply_to(message, ai_response)

            user_id = message.from_user.id
            user_name = message.from_user.first_name or "Неизвестный"
            username = message.from_user.username or "Нет username"
            user_message = message.text

            sent_msg = bot.send_message(
                MANAGER_CHAT_ID,
                f"Клиент {user_name} (ID: {user_id}, @{username}) написал:\n"
                f"'{user_message}'\n\n"
                f"Ответ бота:\n{ai_response}\n\n"
                f"Нажмите 'Ответить', если хотите ответить лично."
            )

            message_map[str(sent_msg.message_id)] = user_id
            save_message_map(message_map)

        except Exception as groq_error:
            print(f"Groq API Error: {groq_error}")

            user_id = message.from_user.id
            user_name = message.from_user.first_name or "Неизвестный"
            username = message.from_user.username or "Нет username"
            user_message = message.text

            sent_msg = bot.send_message(
                MANAGER_CHAT_ID,
                f"Виртуальный менеджер временно недоступен.\n"
                f"Клиент {user_name} (ID: {user_id}, @{username}) спрашивает:\n"
                f"'{user_message}'\n\n"
                f"Нажмите 'Ответить', чтобы написать клиенту лично."
            )

            message_map[str(sent_msg.message_id)] = user_id
            save_message_map(message_map)

            bot.reply_to(
                message,
                "Извините, виртуальный помощник временно недоступен. "
                "Ваш вопрос передан живому менеджеру. Ожидайте ответа."
            )

    except Exception as e:
        print(f"General Error occurred: {e}")


print("Бот успешно запущен!")
bot.infinity_polling()