import sqlite3
import os


def get_tables_info(db_path):
    if not os.path.exists(db_path):
        return {"error": f"Файл не найден: {db_path}"}

    db_data = {}
    try:
        conn = sqlite3.connect(db_path)
        # Это позволит получать данные в виде словарей, а не кортежей
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()

        for table in tables:
            table_name = table['name']
            if table_name == 'sqlite_sequence': continue

            # 1. Структура колонок
            cursor.execute(f"PRAGMA table_info('{table_name}');")
            columns = [col['name'] for col in cursor.fetchall()]

            # 2. Сами данные (последние 10 записей)
            cursor.execute(f"SELECT * FROM '{table_name}' LIMIT 10;")
            rows = cursor.fetchall()

            # Превращаем объекты sqlite.Row в обычные списки для передачи во Flask
            table_rows = [dict(row) for row in rows]

            db_data[table_name] = {
                "columns": columns,
                "rows": table_rows,
                "count": len(table_rows)  # Можно оставить ваш COUNT(*) из прошлого кода
            }

        conn.close()
        return db_data
    except sqlite3.Error as e:
        return {"error": str(e)}