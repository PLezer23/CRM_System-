import os
import show_db
from flask import Flask, render_template_string

app = Flask(__name__)

# Автоматический путь к базе
current_dir = os.path.dirname(os.path.abspath(__file__))
DB_FILE_PATH = os.path.normpath(os.path.join(current_dir, '..', 'bot', 'KOKC.db'))

# Исправленный HTML_TEMPLATE
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Админка</title>
    <style>
        body { font-family: sans-serif; margin: 40px; background: #f4f7f6; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #007bff; color: white; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .badge { background: #28a745; color: white; padding: 4px 8px; border-radius: 4px; font-size: 0.9em; }
    </style>
</head>
<body>
    <h1>Панель управления</h1>

    {% for table_name, info in data.items() %}
        {% if table_name != 'sqlite_sequence' %}
        <div class="card">
            <h2>Таблица: {{ table_name }} <span class="badge">Записей: {{ info.rows|length }}</span></h2>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            {% for col in info.columns %}
                            <th>{{ col }}</th>
                            {% endfor %}
                        </tr>
                    </thead>
                    <tbody>
                        {% for row in info.rows %}
                        <tr>
                            {% for col in info.columns %}
                            <td>{{ row[col] }}</td>
                            {% endfor %}
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
        </div>
        {% endif %}
    {% endfor %}
</body>
</html>
"""

@app.route('/')
def index():
    data = show_db.get_tables_info(DB_FILE_PATH)
    if "error" in data:
        return f"<h1 style='color:red;'>Ошибка: {data['error']}</h1>"

    return render_template_string(HTML_TEMPLATE, data=data, path=DB_FILE_PATH)


app.run(debug=True, port=5000)