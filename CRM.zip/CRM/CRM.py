from groq import Groq
import telebot
from telebot import types
from dotenv import load_dotenv
import sqlite3
from datetime import datetime
import os

load_dotenv()


GROQ_API_KEY = os.getenv('GROK_TOKEN')
TELEGRAM_TOKEN = os.getenv('TG_BOT_TOKEN')
MANAGER_CHAT_ID = os.getenv('MANAGER_CHAT_ID')
MODEL = "openai/gpt-oss-20b"

ADMIN_IDS = [MANAGER_CHAT_ID]

message_map = {}

client = Groq(api_key=GROQ_API_KEY)
bot = telebot.TeleBot(TELEGRAM_TOKEN)

# Инициализация базы данных
conn = sqlite3.connect('KOKC.db', check_same_thread=False)
cursor = conn.cursor()

# Создание таблиц
cursor.execute('''
               CREATE TABLE IF NOT EXISTS clients
               (
                   user_id
                   INTEGER
                   PRIMARY
                   KEY,
                   username
                   TEXT,
                   first_name
                   TEXT,
                   last_name
                   TEXT,
                   first_seen
                   TIMESTAMP
                   DEFAULT
                   CURRENT_TIMESTAMP,
                   last_seen
                   TIMESTAMP
                   DEFAULT  
                   CURRENT_TIMESTAMP
               )
               ''')

cursor.execute('''
               CREATE TABLE IF NOT EXISTS messages
               (
                   id
                   INTEGER
                   PRIMARY
                   KEY
                   AUTOINCREMENT,
                   user_id
                   INTEGER,
                   message
                   TEXT,
                   response
                   TEXT,
                   timestamp
                   TIMESTAMP
                   DEFAULT
                   CURRENT_TIMESTAMP,
                   FOREIGN
                   KEY
               (
                   user_id
               ) REFERENCES clients
               (
                   user_id
               )
                   )
               ''')

cursor.execute('''
               CREATE TABLE IF NOT EXISTS manager_requests
               (
                   id
                   INTEGER
                   PRIMARY
                   KEY
                   AUTOINCREMENT,
                   user_id
                   INTEGER,
                   message
                   TEXT,
                   timestamp
                   TIMESTAMP
                   DEFAULT
                   CURRENT_TIMESTAMP,
                   status
                   TEXT
                   DEFAULT
                   'pending',
                   FOREIGN
                   KEY
               (
                   user_id
               ) REFERENCES clients
               (
                   user_id
               )
                   )
               ''')

conn.commit()


# Функции для работы с БД
def save_or_update_user(user_id, username, first_name, last_name=None):
    cursor.execute('''
        INSERT OR REPLACE INTO clients (user_id, username, first_name, last_name, last_seen)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
    ''', (user_id, username, first_name, last_name))
    conn.commit()


def save_message(user_id, message, response):
    cursor.execute('''
                   INSERT INTO messages (user_id, message, response)
                   VALUES (?, ?, ?)
                   ''', (user_id, message, response))
    conn.commit()


def save_manager_request(user_id, message):
    cursor.execute('''
                   INSERT INTO manager_requests (user_id, message, status)
                   VALUES (?, ?, 'pending')
                   ''', (user_id, message))
    conn.commit()


@bot.message_handler(commands=['start'])
def start_message(message):
    # Сохраняем пользователя
    save_or_update_user(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name,
        message.from_user.last_name
    )

    if message.chat.id in ADMIN_IDS:
        bot.send_message(
            message.chat.id,
            "Вы вошли как администратор. Вы можете отвечать на сообщения клиентов, нажимая 'Ответить' на их сообщения."
        )
        return

    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    item1 = types.KeyboardButton("Услуги")
    item2 = types.KeyboardButton("Кадастровая стоимость")
    item3 = types.KeyboardButton("Документы")
    item4 = types.KeyboardButton("Оформление дома")
    item5 = types.KeyboardButton("Нужен живой менеджер")
    item6 = types.KeyboardButton("Контакты")

    markup.add(item1, item2, item3, item4, item5, item6)

    bot.send_message(
        message.chat.id,
        "Кемеровский Областной Кадастровый Центр приветствует вас!\n"
        "Виртуальный менеджер на связи. Напишите свой вопрос или выберите действие:",
        reply_markup=markup
    )


@bot.message_handler(func=lambda message: message.text in ["Услуги", "Кадастровая стоимость",
                                                           "Документы", "Оформление дома",
                                                           "Нужен живой менеджер", "Контакты"])
def handle_buttons(message):
    if message.chat.id in ADMIN_IDS:
        return

    responses = {
        "Услуги": "Наши услуги:\n• Кадастровый учет\n• Оценка недвижимости\n• Регистрация прав\n• Межевание\n• Технические планы",
        "Кадастровая стоимость": "Для получения кадастровой стоимости необходимо:\n1. Кадастровый номер объекта\n2. Адрес объекта\n\nНапишите эти данные, и мы поможем",
        "Документы": "Основные документы:\n• Паспорт\n• Правоустанавливающие документы\n• Технический паспорт\n• Кадастровый паспорт",
        "Оформление дома": "Для оформления дома нужны:\n• Документы на землю\n• Технический план\n• Разрешение на строительство (если есть)",
        "Нужен живой менеджер": "Сейчас соединю с живым менеджером...",
        "Контакты": "📍 Адрес: , г. Кемерово, пр. Шахтёров, 50\n📞 Телефон: +7 (3842) 44-24-00\n📧 Email: info@kadastr42.ru\n🕒 Режим: Пн-Чт 8:00-17:00, Пт 08:00 -15:00\nГенеральный директор — Артёмов Алексей Владимирович."
    }

    if message.text == "Нужен живой менеджер":
        connect_to_manager(message)
    else:
        bot.reply_to(message, responses.get(message.text, "Выберите пункт меню"))


def connect_to_manager(message):
    user_id = message.from_user.id
    user_name = message.from_user.first_name or "Неизвестный"
    username = message.from_user.username or "Нет username"

    save_manager_request(user_id, message.text)

    sent_msg = bot.send_message(
        MANAGER_CHAT_ID,
        f"Клиент {user_name} (ID: {user_id}, @{username}) просит помощи!\n"
        f"Сообщение: {message.text}\n\n"
        f"Нажмите 'Ответить' на это сообщение, чтобы написать клиенту."
    )

    message_map[sent_msg.message_id] = user_id
    bot.reply_to(message, "Менеджер скоро ответит вам. Ожидайте ответа в этом чате.")


@bot.message_handler(func=lambda message: True)
def answer(message):
    try:
        if message.chat.id in ADMIN_IDS:
            if message.reply_to_message is not None:
                return
            else:
                bot.send_message(
                    message.chat.id,
                    "Вы администратор. Используйте функцию 'Ответить' на сообщениях клиентов для связи с ними."
                )
                return

        if message.text == "Нужен живой менеджер":
            connect_to_manager(message)
            return

        if message.text in ["Услуги", "Кадастровая стоимость", "Документы",
                            "Оформление дома", "Контакты"]:
            return

        try:
            chat_completion = client.chat.completions.create(
                messages=[
                    {
                        "role": "system",
                        "content": "Ты - виртуальный помощник Кемеровского Областного Кадастрового Центра. "
                                   "Ты помогаешь с вопросами о кадастровой стоимости, оформлении документов, "
                                   "документах для кадастрового учета. Отвечай вежливо, профессионально и по делу. "
                                   "Если не знаешь точного ответа, предложи обратиться к специалисту центра. "
                                   "Отвечай обычным текстом, без markdown разметки. "
                                   "Если вопрос не относится к кадастру или недвижимости, вежливо сообщи, "
                                   "что это не входит в компетенцию центра.Информация центра: Контакты📍 Адрес: , г. Кемерово, пр. Шахтёров, 50\n📞 Телефон: +7 (3842) 44-24-00\n📧 Email: info@kadastr42.ru\n🕒 Режим: Пн-Чт 8:00-17:00, Пт 08:00 -15:00\nГенеральный директор — Артёмов Алексей Владимирович."
                    },
                    {
                        "role": "user",
                        "content": message.text,
                    }
                ],
                model=MODEL,
                temperature=0.7,
                max_tokens=1024
            )

            ai_response = chat_completion.choices[0].message.content
            bot.reply_to(message, ai_response)

            save_message(message.from_user.id, message.text, ai_response)

            save_or_update_user(
                message.from_user.id,
                message.from_user.username,
                message.from_user.first_name,
                message.from_user.last_name
            )

            user_id = message.from_user.id
            user_name = message.from_user.first_name or "Неизвестный"
            username = message.from_user.username or "Нет username"
            user_message = message.text

            bot.send_message(
                MANAGER_CHAT_ID,
                f"Клиент {user_name} (ID: {user_id}, @{username}) написал:\n"
                f"'{user_message}'\n\n"
                f"Бот ответил автоматически.\n"
                f"Ответ бота:\n{ai_response}\n\n"
                f"Нажмите 'Ответить', если хотите ответить лично."
            )

        except Exception as groq_error:
            print(f"Groq API Error: {groq_error}")

            user_id = message.from_user.id
            user_name = message.from_user.first_name or "Неизвестный"
            username = message.from_user.username or "Нет username"
            user_message = message.text

            save_manager_request(user_id, user_message)

            sent_msg = bot.send_message(
                MANAGER_CHAT_ID,
                f"Виртуальный менеджер временно недоступен.\n"
                f"Клиент {user_name} (ID: {user_id}, @{username}) спрашивает:\n"
                f"'{user_message}'\n\n"
                f"Нажмите 'Ответить', чтобы написать клиенту лично."
            )

            message_map[sent_msg.message_id] = user_id

            bot.reply_to(
                message,
                "Извините, виртуальный помощник временно недоступен. "
                "Ваш вопрос передан живому менеджеру. Ожидайте ответа."
            )

    except Exception as e:
        print(f"General Error occurred: {e}")
        if message.chat.id not in ADMIN_IDS:
            bot.reply_to(message, "Извините, произошла ошибка. Пожалуйста, попробуйте позже.")


@bot.message_handler(func=lambda message:
message.chat.id == MANAGER_CHAT_ID and
message.reply_to_message is not None
                     )
def manager_reply(message):
    try:
        replied_msg_id = message.reply_to_message.message_id

        if replied_msg_id in message_map:
            client_id = message_map[replied_msg_id]

            save_message(client_id, f"Ответ менеджера: {message.reply_to_message.text}", message.text)

            bot.send_message(
                client_id,
                f"Ответ от менеджера:\n\n{message.text}"
            )

            bot.reply_to(message, "Ответ успешно отправлен клиенту!")

            del message_map[replied_msg_id]
        else:
            bot.reply_to(message,
                         "Не удалось отправить ответ. Возможно, клиент уже получил ответ или сообщение устарело.")

    except Exception as e:
        print(f"Manager reply error: {e}")
        bot.reply_to(message, f"Ошибка при отправке: {e}")


@bot.message_handler(func=lambda message: message.chat.id in ADMIN_IDS)
def handle_admin_messages(message):
    if message.reply_to_message is None:
        bot.send_message(
            message.chat.id,
            "Вы администратор. Чтобы ответить клиенту, нажмите 'Ответить' на его сообщении."
        )


bot.infinity_polling()